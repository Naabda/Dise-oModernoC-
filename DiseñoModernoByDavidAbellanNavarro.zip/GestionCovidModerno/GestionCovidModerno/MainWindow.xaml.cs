﻿/**
 * @author David Abellán Navarro
 * @Date 15/10/2021
 */
using System.Windows;

namespace GestionCovidModerno
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void RadioButton_Checked(object sender, RoutedEventArgs e)
        {

        }
    }
}
